
<script src="{{asset('admin/vendor/echarts/echarts.min.js')}}"></script>

<script src="{{asset('admin/vendor/jquery/jquery.min.js')}}"></script>
<script src="{{asset('admin/vendor/popper/popper.min.js')}}"></script>
<script src="{{asset('admin/vendor/bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{asset('admin/vendor/select2/js/select2.full.min.js')}}"></script>
<script src="{{asset('admin/vendor/simplebar/simplebar.js')}}"></script>
<script src="{{asset('admin/vendor/text-avatar/jquery.textavatar.js')}}"></script>
<script src="{{asset('admin/vendor/tippyjs/tippy.all.min.js')}}"></script>
<script src="{{asset('admin/vendor/flatpickr/flatpickr.min.js')}}"></script>
<script src="{{asset('admin/vendor/wnumb/wNumb.js')}}"></script>
<script src="{{asset('admin/js/main.js')}}"></script>


<script src="{{asset('admin/vendor/jquery-circle-progress/circle-progress.min.js')}}"></script>
<script src="{{asset('admin/js/preview/default-dashboard.min.js')}}"></script>
